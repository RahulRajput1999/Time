#include<bits/stdc++.h>
using namespace std;

int main(){
	stack <int> stk;
	stk.push(1);
	stk.push(2);
	cout<<stk.top();
	cout<<stk.size();
	return 0;
}
