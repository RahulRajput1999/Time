#include<bits/stdc++.h>
using namespace std;

void naive(char P[], char T[]){
	int p,t,i,j,flag,a;
	p = strlen(P);
	t = strlen(T);
	
	for(i=0;i<=(t-p);i++){
		
		for(j=0;j<p;j++){
			if(P[j]!=T[j+i]){
				flag = 1;
				a=i+1;
				break;
			}
		}
		if(flag==0)
		{
			cout<<a<<" "<<"is valid shift"<<endl;
		}
		flag=0;
	}
}

int main(){
	char P[1000],T[1000];
	cout<<"Enter the string:"<<endl;
	cin.getline(T,sizeof(T));
	cout<<"Enter the pattern:"<<endl;
	cin.getline(P,sizeof(P));
	naive(P,T);
	return 0;	
}
