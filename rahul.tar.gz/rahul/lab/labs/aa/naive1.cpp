#include<bits/stdc++.h>
using namespace std;
void naive(string T,string P)
{	
	long long int n,m,i,j,f=0,a=0;
	n=T.length();
	m=P.length();
	for(i=0;i<=(n-m);i++)
	{
		for(j=0;j<m;j++)
		{
			if(P[j]!=T[i+j])
			{
				f=1;
				a=i+1;
				break;
			}
		}
		if(f==0)
		{
			cout<<a<<" "<<"is valid shift"<<endl;
		}
		f=0;
		
	}
}
int main()
{
	string T,P;
	cout<<"Enter ur text:"<<endl;
	cin>>T;
	cout<<"Enter a pattern u want to find:"<<endl;
	cin>>P;
	naive(T,P);
	
	return 0;
}
