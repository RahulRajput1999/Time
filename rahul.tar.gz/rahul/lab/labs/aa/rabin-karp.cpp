#include<bits/stdc++.h>
using namespace std;

void rabinKarp(char P[],char T[]){
	int p=strlen(P),t=strlen(T),i,j,flag,mod=127,d=100,t1=0,t2=0,tmp;
	tmp = pow(100,p-1);
	tmp = tmp%mod;
	for(i=0;i<p;i++){
		t1=((((t1%mod)*100)%mod)+(P[i]-24))%mod;
		t2=((((t2%mod)*100)%mod)+(T[i]-24))%mod;
	}
	if(t1<0){
		t1 = t1+mod;
	}
	if(t2<0){
		t2 = t2+mod;
	}
	for(i=0;i<=t-p;i++){
		if(t1==t2){
			int f=0;
			for(j=0;j<p;j++){
				if(T[i+j]!=P[j]){
					f=1;
				}
			}
			if(f==0){
				cout<<"At index:"<<i<<endl;
			}
			int tmp1 = ((T[i]-24)*tmp)%mod;
			t2 = (t2%mod - tmp1%mod)%mod;
			t2 = (((t2%mod)*(100))%mod+(T[i+p]-24))%mod;
			if(t2<0){
				t2=t2+mod;
			}
			
		}
		else{
			
			int tmp1 = ((T[i]-24)*tmp)%mod;
			t2 = (t2%mod - tmp1%mod)%mod;
			t2 = (((t2%mod)*(100))%mod+(T[i+p]-24))%mod;
			if(t2<0){
				t2=t2+mod;
			}
		}
	}

	
}
int main(){
	char P[1000],T[1000];
	cout<<"Enter the string:"<<endl;
	cin.getline(T,sizeof(T));
	cout<<"Enter the pattern:"<<endl;
	cin.getline(P,sizeof(P));
	rabinKarp(P,T);
	return 0;	
}
