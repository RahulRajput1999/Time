 #include<iostream>
 #include<bits/stdc++.h>
 #include<math.h>
 using namespace std;
 void robinkarp(int n,int m,int T[],int P[])
 {
 	int h=1,t=0,p=0,i=0,d=10,q=17,s=0,f=0,a=0,temp=0;
 	h=pow(d,m-1);
 	h=h%q;
 	for(i=0;i<m;i++)
 	{
 		p=(d*p+P[i])%q;
 		t=(d*t+T[i])%q;
 	}   
 	cout<<t<<" "<<p<<endl;                                                                            
 	for(s=0;s<=(n-m);s++)
 	{
 		if(t==p)
 		{
 			f=0;
 			for(i=0;i<m;i++)
 			{
 				if(P[i]!=T[s+i]);
 				{
 					f=1;
 					a=i+1;
 					break;
 				}
 			}
 			if(f==0)
 			{
 				cout<<a<<" "<<"is valid shift."<<endl;
 			}
 		}
 		else
 		{	
 			if(s<(n-m))
 			{
 				temp=(d*(t-T[s+1]*h))+(T[s+m+1])%q;
 				if(temp<0)
 					t=temp+q;
 				else
 					t=temp;
 			}
 			
 		}
 	}
 }
 int main()
{
	int n,m,i;
	cout <<"Enter size of ur number:"<<endl;
	cin>>n;
	int T[n];
	cout<<"Enter ur number:"<<endl;
	for(i=0;i<n;i++)
	{
		cin>>T[i];
	}
	cout<<"Enter size of pattern"<<endl;
	cin>>m;
	int P[m];
	cout<<"Enter a pattern u want to find:"<<endl;
	for(i=0;i<m;i++)
	{
		cin>>P[i];
	}
	robinkarp(n,m,T,P);
	return 0;
	 
}

