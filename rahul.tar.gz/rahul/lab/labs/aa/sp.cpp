#include<bits/stdc++.h>
using namespace std;
 struct point
 {
 	int x,y;
 	double a;
 };

bool compare(struct point p1,struct point p2){
	return (p1.a<p2.a);
}
 
 int main(){
 	int x1,y1,n,i,j=0,k=0,minx=0,miny=0;
 	double dx,dy,tan,ang;
 	printf("Enter n:");
 	scanf("%d",&n);
 	struct point P[n],neg[n],pos[n];
 	for(i=0;i<n;i++){
 		scanf("%d,%d",&x1,&y1);
 		P[i].x=x1;
 		P[i].y=y1;
 	}
 	for(i=0;i<n;i++){
 		if(P[i].y<P[miny].y){
 			miny = i;
 		}
 	}
 	minx = miny;
 	for(i=0;i<n;i++){
 		if(P[i].y == P[miny].y){
 			if(P[i].x<P[minx].x){
 				minx = i;
 			}
 		}
 	}
 	printf ("\nmin point=%d,%d\n",P[minx].x,P[minx].y);
 	for(i=0;i<n;i++){
 		if(i!=minx){
	 		dx =(double) (P[i].x - P[minx].x);
	 		dy = (double) (P[i].y - P[minx].y);
	 		tan = dy/dx;
	 	}
	 	else{
	 		ang = 0;
	 	}
	 	if(tan<0){
	 		P[i].a = tan;
	 		neg[j].x = P[i].x;
	 		neg[j].y = P[i].y;
	 		neg[j].a = tan;
	 		j++;
	 	}
	 	else{
	 		P[i].a = tan;
	 		pos[k].x = P[i].x;
	 		pos[k].y = P[i].y;
	 		pos[k].a = tan;
	 		k++;
	 	}
 	}
 	sort(pos,pos+k,compare);
 	sort(neg,neg+j,compare);
 	int in=0;
 	for(i=0;i<k;i++){
 		P[in] = pos[i];
 		in++;
 	}
 	for(i=0;i<j;i++){
 		P[in] = neg[i];
 		in++;
 	}
 	for(i=0;i<n;i++){
 		printf("%d,%d\n",P[i].x,P[i].y);
 	}
 }
