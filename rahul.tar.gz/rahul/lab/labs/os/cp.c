#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdio.h>
#include<string.h>

int main(int argc,char** argv)
{
	int i;
	int in=open(argv[1],O_RDONLY);
	int out=open(argv[2],O_WRONLY);
	if(out==(-1))
	{
		out=open(argv[2],O_CREAT|O_WRONLY,S_IRWXU);
		char tmp[5];
		while(read(in,tmp,1))
		{
			write(out,tmp,1);
		}
		close(in);
		close(out);
	}
	else
	{
		char tmp[5];
		while(read(in,tmp,1))
		{
			write(out,tmp,1);
		}
		close(in);
		close(out);
	}
	return 0;
}
