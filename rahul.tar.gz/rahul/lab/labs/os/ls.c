#include<stdio.h>
#include<unistd.h>
#include<dirent.h>
#include<string.h>
void printdir(char*,DIR*);
void main(){
	char buf[1000],*path;
	path = getcwd(buf,100);
	DIR *dir = opendir(buf);
	struct dirent *d = readdir(dir);
	printdir(path,opendir(buf));
	printf("\n");
		
}

void printdir(char *path,DIR *d){
	DIR *d1 = d;
	struct dirent *dent = readdir(d);
	while(dent!=NULL){
		printf("%s	",dent->d_name);
		if((dent->d_type == DT_DIR) && (strcmp(dent->d_name,".")!=0) && (strcmp(dent->d_name,"..")!=0)){
			path = strcat(path,"/");
			path = strcat(path,dent->d_name);
			DIR * dr = opendir(path);
			printdir(path,dr);
		}
		dent=readdir(d);
	}
	struct dirent *d2 = readdir(d);
	while(d2!=NULL){
		printf("checking for inner dir");
		char *path1;
		if(d2->d_type == DT_DIR){
			path1 = strcat(path,"/");
			path1 = strcat(path1,d2->d_name);
			DIR *d3 = opendir(path1);
			printdir(path1,d3);
		}
	}
	
}
