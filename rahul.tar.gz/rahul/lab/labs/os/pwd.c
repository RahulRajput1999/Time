#include<stdio.h>
#include<unistd.h>

void main(){
	char buf[1000];
	int size = sizeof(buf);
	printf("by using getcwd():-%s\n",getcwd(buf,size));
	printf("buf:-%s\n",buf);
	printf("by using get_current_dir_name():-%s\n",get_current_dir_name());
}
