#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdio.h>
#include<string.h>

int main(int argc,char** argv)
{
	int i;

	if(argc==1)
	{
		char a[100];
		while(1)
		{
			int n=read(0,a,sizeof(a));
			write(1,a,n);
		}
	}
	else
	{
		for(i=1;i<argc;i++)
		{
			int fd=open(argv[i],O_RDONLY);
			char tmp[5];
			while(read(fd,tmp,1))
			{
				write(1,tmp,1);
			}
			close(fd);
		}
	}
	return 0;
}
